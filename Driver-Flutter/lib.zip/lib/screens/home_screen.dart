// lib/screens/home_screen.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:vibration/vibration.dart';
import 'package:disable_battery_optimization/disable_battery_optimization.dart';
import '../services/auto_resume_handler.dart';
import '../services/route_service.dart';
import '../utils/constants.dart';
import '../utils/permissions_helper.dart';
import '../widgets/admin_dialogs.dart';
import '../widgets/log_dialog.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  dynamic isTracking = false;
  String statusMessage = "Stopped";
  bool isButtonPressed = false;
  String? selectedRouteId;
  List<String> routes = [];
  bool isLoadingRoutes = true;
  
  final RouteService _routeService = RouteService();
  IO.Socket? _uiSocket;
  String? _uiSocketId;
  
  final List<String> _logs = [];
  final int _maxLogs = 100;
  Timer? _longPressTimer;
  int _vibrationCount = 0;
  
  AutoResumeHandler? _autoResumeHandler;

  @override
  void initState() {
    super.initState();
    _autoResumeHandler = AutoResumeHandler(onStatusSync: (newState) {
      if (mounted && (isTracking != newState)) {
        _log("Status synchronized by handler: Tracking is now ${newState ? 'ON' : 'OFF'}");
        setState(() {
          isTracking = newState;
          statusMessage = newState ? "Tracking Active" : "Stopped";
        });
      }
    });
    _initialize();
  }

  @override
  void dispose() {
    _autoResumeHandler?.dispose();
    _uiSocket?.dispose();
    _longPressTimer?.cancel();
    super.dispose();
  }

  void _initialize() async {
    await _loadTrackingState();
    await PermissionsHelper.checkAndRequestPermissions();
    _log("App Initialized");
    _listenToBackgroundService();
    await _loadRoutes();
    await _loadSelectedRoute();
    if (selectedRouteId != null) {
      _setupUiSocket();
      // Start tracking if location_started is true
      final prefs = await SharedPreferences.getInstance();
      bool wasTracking = prefs.getBool('location_started') ?? false;
      if (wasTracking && !isTracking) {
        await _toggleTracking();
      }
    }
    if (mounted) setState(() => isLoadingRoutes = false);
  }
  
  Future<void> _loadTrackingState() async {
    final prefs = await SharedPreferences.getInstance();
    bool wasTracking = prefs.getBool('location_started') ?? false;
    if (mounted) {
      setState(() { 
        isTracking = wasTracking;
        statusMessage = wasTracking ? "Tracking Active" : "Stopped";
      });
    }
    _log("Loaded initial tracking state: $wasTracking");
  }

  void _listenToBackgroundService() {
    FlutterBackgroundService().on('updateUI').listen((event) {
      if (mounted && event != null) {
        final bool newTrackingState = event['isTracking'] ?? false;
        final String newStatus = event['status'] ?? "Unknown";
        
        setState(() {
          isTracking = newTrackingState;
          statusMessage = newStatus;
        });
        
        _log("Service Update: Tracking=$newTrackingState, Status=$newStatus");
      }
    });
  }

  void _setupUiSocket() {
    _uiSocket?.disconnect();
    _uiSocket = IO.io(
      websocketUrl,
      IO.OptionBuilder()
          .setTransports(['websocket'])
          .setQuery({'role': 'Driver', 'route_id': selectedRouteId ?? 'Unknown'})
          .disableAutoConnect()
          .build(),
    );

    _uiSocket!.onConnect((_) {
      _uiSocketId = _uiSocket!.id;
      _log("UI Socket Connected: $_uiSocketId");
      if (mounted) setState(() {});
    });

    _uiSocket!.onDisconnect((_) {
      _log("UI Socket Disconnected");
      if (mounted) setState(() {});
    });

    _uiSocket!.on('disconnect_by_admin', (data) {
      _log("Admin disconnect command received.");
      if (data != null && data['socket_id'] == _uiSocketId) {
        if (isTracking == true) {
          _stopTrackingService();
        }
        _showAdminDisconnectAlert();
      }
    });

    _uiSocket!.connect();
  }

  Future<void> _loadRoutes() async {
    try {
      final loadedRoutes = await _routeService.getRoutes();
if (mounted) setState(() => routes = loadedRoutes);
    } catch (e) {
      _log("Error loading routes: $e");
    }
  }

  Future<void> _handleRefreshRoutes() async {
    if (mounted) setState(() => isLoadingRoutes = true);
    try {
      final refreshedRoutes = await _routeService.refreshRoutes();
      if (mounted) {
        setState(() {
          routes = refreshedRoutes;
          if (!routes.contains(selectedRouteId)) {
            selectedRouteId = routes.isNotEmpty ? routes.first : null;
          }
        });
      }
    } finally {
      if (mounted) setState(() => isLoadingRoutes = false);
    }
  }

  Future<void> _loadSelectedRoute() async {
    final prefs = await SharedPreferences.getInstance();
    final storedRouteId = prefs.getString("selectedRoute");
    if (storedRouteId != null && routes.contains(storedRouteId)) {
      selectedRouteId = storedRouteId;
    } else if (routes.isNotEmpty) {
      selectedRouteId = routes.first;
      await prefs.setString("selectedRoute", selectedRouteId!);
    }
    if (mounted) setState(() {});
  }

  Future<void> _onRouteChanged(String? newRoute) async {
    if (newRoute == null || newRoute == selectedRouteId) return;
    if (isTracking == true) await _stopTrackingService();
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString("selectedRoute", newRoute);
    setState(() => selectedRouteId = newRoute);
    _setupUiSocket();
    // Check if tracking should resume after route change
    bool wasTracking = prefs.getBool('location_started') ?? false;
    if (wasTracking) {
      await _toggleTracking();
    }
  }

  Future<void> _stopTrackingService() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('location_started', false);
    final service = FlutterBackgroundService();
    service.invoke("stopTracking", {'route_id': selectedRouteId}); 
    if (mounted) {
      setState(() {
        isTracking = false;
        statusMessage = "Stopped";
      });
    }
    _log("Tracking stopped manually");
  }
  
  Future<bool> _checkAndRequestBatteryOptimizations() async {
    bool isBatteryOptimizationDisabled = await DisableBatteryOptimization.isBatteryOptimizationDisabled ?? false;
    if (!isBatteryOptimizationDisabled) {
      await DisableBatteryOptimization.showDisableBatteryOptimizationSettings();
    }
    bool isManBatteryOptimizationDisabled = await DisableBatteryOptimization.isManufacturerBatteryOptimizationDisabled ?? false;
    if (!isManBatteryOptimizationDisabled) {
      await DisableBatteryOptimization.showDisableManufacturerBatteryOptimizationSettings(
        "Your device has additional battery settings",
        "Follow the steps to allow the app to run in the background."
      );
    }
    bool isAutoStartEnabled = await DisableBatteryOptimization.isAutoStartEnabled ?? false;
    if (!isAutoStartEnabled) {
      await DisableBatteryOptimization.showEnableAutoStartSettings(
        "Enable Auto Start",
        "Follow the steps to enable auto-start for uninterrupted service."
      );
    }
    return true;
  }

  Future<void> _toggleTracking() async {
    if (isTracking == true) {
      setState(() => isTracking = null);
      await _stopTrackingService();
      return;
    }

    if (selectedRouteId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Please select a route first.")));
      return;
    }

    final hasPermission = await Permission.location.isGranted;
    if (!hasPermission) {
      await PermissionsHelper.checkAndRequestPermissions();
      return;
    }

    final hasBackgroundPermission = await Permission.locationAlways.isGranted;
    if (!hasBackgroundPermission) {
      if (mounted) PermissionsHelper.showBackgroundPermissionDialog(context);
      return;
    }
    
    await _checkAndRequestBatteryOptimizations();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('location_started', true);

    final service = FlutterBackgroundService();
    service.invoke("startTracking", {'route_id': selectedRouteId});
    if (mounted) {
      setState(() {
        isTracking = true;
        statusMessage = "Starting...";
      });
    }
    _log("Tracking started manually for route: $selectedRouteId");
  }

  void _log(String message) {
    if (!mounted) return;
    final now = DateTime.now();
    final timestamp = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
    setState(() {
      _logs.add("[$timestamp] $message");
      if (_logs.length > _maxLogs) _logs.removeLast();
    });
  }

  void _showAdminDisconnectAlert() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Disconnected by Admin"),
        content: const Text("Your session has been terminated."),
        actions: [TextButton(child: const Text("OK"), onPressed: () => Navigator.pop(context))],
      ),
    );
  }
  
  void _handleAdminTap() {
    showAdminPasswordPanel(context, () {
      showAdminOptions(
        context,
        onRefreshRoutes: () { Navigator.pop(context); _handleRefreshRoutes(); },
        onViewLogs: () { Navigator.pop(context); showLogDialog(context, List.from(_logs.reversed), () => setState(() => _logs.clear())); },
        onReconnectSocket: () { Navigator.pop(context); _setupUiSocket(); },
      );
    });
  }

  void _startLongPressVibration() {
    _vibrationCount = 0;
    _longPressTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_vibrationCount >= 5) {
        timer.cancel();
        showLogDialog(context, List.from(_logs.reversed), () => setState(() => _logs.clear()));
      } else {
        Vibration.vibrate(duration: 100);
        _vibrationCount++;
      }
    });
  }

  void _stopLongPressVibration() => _longPressTimer?.cancel();
  
  @override
  Widget build(BuildContext context) {
    final bool isConnected = _uiSocket?.connected ?? false;
    final Color statusColor = isTracking == true ? Colors.green.shade800 : Colors.red.shade800;

    return Scaffold(
      appBar: AppBar(
        title: const Text("VJ Bus Driver"), 
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: isTracking == true ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.circle,
                  size: 12,
                  color: isTracking == true ? Colors.green : Colors.red,
                ),
                const SizedBox(width: 4),
                Text(
                  isTracking == true ? "LIVE" : "OFF",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: isTracking == true ? Colors.green.shade800 : Colors.red.shade800,
                  ),
                ),
              ],
            ),
          ),
          IconButton(icon: const Icon(Icons.admin_panel_settings), onPressed: _handleAdminTap, tooltip: "Admin Panel")
        ]
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (isLoadingRoutes) const CircularProgressIndicator()
              else if (routes.isEmpty) const Text("No routes available.")
              else DropdownButton<String>(
                  value: selectedRouteId, isExpanded: true,
                  items: routes.map((r) => DropdownMenuItem(value: r, child: Text(r, style: const TextStyle(fontSize: 18)))).toList(),
                  onChanged: _onRouteChanged,
              ),
              const SizedBox(height: 40),
              Text(isTracking == true ? "Bus Started" : "Bus Stopped", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: statusColor)),
              if (selectedRouteId != null) Text("Route: $selectedRouteId", style: const TextStyle(fontSize: 16)),
              Text(isConnected ? "Connected to Admin" : "Disconnected from Admin", style: TextStyle(fontSize: 14, color: isConnected ? Colors.green : Colors.red)),
              const SizedBox(height: 30),
              GestureDetector(
                onTap: _toggleTracking,
                onTapDown: (_) => setState(() => isButtonPressed = true),
                onTapUp: (_) => setState(() => isButtonPressed = false),
                onTapCancel: () => setState(() => isButtonPressed = false),
                onLongPressStart: (_) => _startLongPressVibration(),
                onLongPressEnd: (_) => _stopLongPressVibration(),
                child: AnimatedScale(
                  scale: isButtonPressed ? 0.95 : 1.0,
                  duration: const Duration(milliseconds: 150),
                  child: Container(
                    width: 150, height: 150,
                    decoration: BoxDecoration(color: isTracking == true ? Colors.red.shade700 : Colors.blue.shade700, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.3), spreadRadius: 2, blurRadius: 10)]),
                    alignment: Alignment.center,
                    child: isTracking == null
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(isTracking == true ? "STOP" : "START", style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}