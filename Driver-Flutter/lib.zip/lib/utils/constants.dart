const String websocketUrl = "wss://dev-bus.vjstartup.com";
const String adminPassword = "123";

const double targetLatitude = 17.539883;
const double targetLongitude = 78.386531;
const double stopRadius = 500; // in meters
