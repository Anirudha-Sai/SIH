// lib/services/auto_resume_handler.dart

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AutoResumeHandler with WidgetsBindingObserver {
  final Function(bool) onStatusSync;
  Timer? _statusSyncTimer;

  AutoResumeHandler({required this.onStatusSync}) {
    WidgetsBinding.instance.addObserver(this);
    _startStatusSynchronization();
  }

  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _statusSyncTimer?.cancel();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _syncTrackingStatus();
    }
  }

  void _startStatusSynchronization() {
    // Periodically sync the status every 15 seconds as a fallback.
    _statusSyncTimer = Timer.periodic(const Duration(seconds: 15), (timer) {
      _syncTrackingStatus();
    });
    
    // Also perform an initial sync shortly after the app starts.
    Timer(const Duration(seconds: 2), () {
      _syncTrackingStatus();
    });
  }
  
  /// Reads the `location_started` flag from local storage and updates the UI.
  Future<void> _syncTrackingStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final bool storedTrackingState = prefs.getBool('location_started') ?? false;
      onStatusSync(storedTrackingState);
    } catch (e) {
      // Log errors if necessary
    }
  }
}
