// lib/services/background_service.dart

import 'dart:async';
import 'dart:ui';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_background_service_android/flutter_background_service_android.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:geolocator/geolocator.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../utils/constants.dart';
import '../main.dart';

Future<void> initializeService() async {
  final service = FlutterBackgroundService();

  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      isForegroundMode: true,
      autoStart: true,
      notificationChannelId: notificationChannelId,
      initialNotificationTitle: 'VJ Bus Service',
      initialNotificationContent: 'Ready to track.',
      foregroundServiceNotificationId: 888,
    ),
    iosConfiguration: IosConfiguration(onForeground: onStart, autoStart: true),
  );

  await service.startService();
}

@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();

  IO.Socket? socket;
  Timer? trackingTimer;
  String? currentSocketId;
  String? activeRouteId;
  bool isTracking = false;
  bool isConnected = false;
  bool sendAsUpdate = false;

  StreamSubscription? startTrackingSubscription;
  StreamSubscription? stopTrackingSubscription;

  Future<void> _cleanupResources({bool sendFinalBroadcast = false}) async {
    if (sendFinalBroadcast && socket != null && socket!.connected && activeRouteId != null) {
      await _sendFinalBroadcast(socket, activeRouteId, () => currentSocketId);
    }

    trackingTimer?.cancel();
    trackingTimer = null;
    socket?.disconnect();
    socket = null;
    currentSocketId = null;
    isTracking = false;
    isConnected = false;
    WakelockPlus.disable();
  }

  Future<void> _startLocationBroadcasting(String routeId) async {
    if (isTracking && activeRouteId == routeId && socket != null && socket!.connected) {
      return;
    }

    await _cleanupResources(sendFinalBroadcast: false);
    activeRouteId = routeId;
    socket = _connectSocket(routeId, "Driver");

    socket!.onConnect((_) {
      if (!socket!.connected) return;

      currentSocketId = socket!.id;
      isConnected = true;
      isTracking = true;

      WakelockPlus.enable();
      service.invoke('updateUI', {'isTracking': true, 'status': 'Connected'});
      _updateNotification(title: "Tracking Active", content: "Live location shared for Route: $activeRouteId");

      trackingTimer ??= Timer.periodic(const Duration(seconds: 5), (timer) async {
        if (socket == null || !socket!.connected || !isTracking || activeRouteId == null) {
          timer.cancel();
          trackingTimer = null;
          _updateNotification(title: "Connection Lost", content: "Attempting to reconnect...");
          return;
        }

        if (timer != trackingTimer) {
          timer.cancel();
          return;
        }

        try {
          Position position = await Geolocator.getCurrentPosition(
            forceAndroidLocationManager: true,
            timeLimit: const Duration(seconds: 10),
          );

          socket!.emit(sendAsUpdate ? "location_update" : "check_location", {
            "route_id": activeRouteId,
            "latitude": position.latitude,
            "longitude": position.longitude,
            "socket_id": currentSocketId,
            "role": "Driver",
            "heading": position.heading,
            "status": sendAsUpdate ? "tracking_active" : "checking",
            "timestamp": DateTime.now().millisecondsSinceEpoch,
          });

          _updateNotification(
            title: "Tracking Active",
            content: "Live location shared for Route: $activeRouteId",
          );
        } catch (e) {
          _updateNotification(
            title: "Location Error",
            content: "Failed to get current location: ${e.toString()}",
          );
        }
      });
    });

    socket!.on("start_now", (_) async {
      final prefs = await SharedPreferences.getInstance();
      final String today = "${DateTime.now().year}-${DateTime.now().month.toString().padLeft(2, '0')}-${DateTime.now().day.toString().padLeft(2, '0')}`";
      final String? lastDate = prefs.getString('last_start_now_date');

      if (lastDate != today) {
        await prefs.setString('last_start_now_date', today);
        sendAsUpdate = true;
      }
    });

    socket!.on("admin_disconnect", (_) async {
      await _cleanupResources(sendFinalBroadcast: true);
      _updateNotification(title: "Disconnected", content: "Admin stopped tracking.");
      service.invoke('updateUI', {'isTracking': false, 'status': 'Stopped by Admin'});
    });

    socket!.onConnectError((error) {
      isConnected = false;
      _updateNotification(title: "Connection Error", content: "Failed to connect: $error");
      service.invoke('updateUI', {'isTracking': false, 'status': 'Connection Error'});
      Timer(const Duration(seconds: 5), () {
        if (!isConnected && isTracking && activeRouteId == routeId) {
          socket?.connect();
        }
      });
    });

    socket!.onDisconnect((_) {
      isConnected = false;
      if (isTracking) {
        service.invoke('updateUI', {'isTracking': false, 'status': 'Connection Lost'});
        trackingTimer?.cancel();
        trackingTimer = null;
        WakelockPlus.disable();
        _updateNotification(title: "Disconnected", content: "Service on standby.");
        Timer(const Duration(seconds: 5), () {
          if (!isConnected && isTracking && activeRouteId == routeId) {
            socket?.connect();
          }
        });
      }
    });
  }

  final prefs = await SharedPreferences.getInstance();
  final String? storedRouteId = prefs.getString('selectedRoute');
  final DateTime now = DateTime.now();
  final DateTime sixThirty = DateTime(now.year, now.month, now.day, 6, 30);
  final DateTime elevenAM = DateTime(now.year, now.month, now.day, 11, 0);
  final String todayKey = "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}`";
  final String? lastStartNowDate = prefs.getString('last_start_now_date');

  if (lastStartNowDate == todayKey) {
    sendAsUpdate = true;
  } else {
    sendAsUpdate = false;
  }

  if (now.isAfter(sixThirty) && now.isBefore(elevenAM) && storedRouteId != null) {
    await _startLocationBroadcasting(storedRouteId);
  }

  if (service is AndroidServiceInstance) {
    service.on('setAsForeground').listen((event) => service.setAsForegroundService());
    service.on('setAsBackground').listen((event) => service.setAsBackgroundService());
  }

  stopTrackingSubscription = service.on('stopTracking').listen((event) async {
    if (!isTracking) return;
    final routeId = event?['route_id'] as String?;
    activeRouteId = routeId;
    await _cleanupResources(sendFinalBroadcast: true);
    _updateNotification(title: "Tracking Stopped", content: "Service is on standby.");
    service.invoke('updateUI', {'isTracking': false, 'status': 'Stopped'});
  });

  startTrackingSubscription = service.on('startTracking').listen((event) async {
    if (event == null) return;
    final routeId = event['route_id'] as String?;
    if (routeId == null) return;
    await _startLocationBroadcasting(routeId);
  });

  service.on('stopService').listen((event) async {
    await _cleanupResources(sendFinalBroadcast: true);
    startTrackingSubscription?.cancel();
    stopTrackingSubscription?.cancel();
    service.stopSelf();
  });
}

Future<void> _sendFinalBroadcast(IO.Socket? socket, String? routeId, String? Function() getSocketId) async {
  if (socket == null || !socket.connected || routeId == null) return;

  try {
    Position? position = await Geolocator.getLastKnownPosition();

    // Fallback to current position if last known is unavailable
    position ??= await Geolocator.getCurrentPosition(
      timeLimit: const Duration(seconds: 5),
    );

    if (position == null) {
      _updateNotification(title: "Location Error", content: "Could not fetch final location.");
      return; // 🔥 Don't crash if still null
    }

    final socketId = getSocketId();
    if (socketId != null) {
      socket.emit("location_update", {
        "route_id": routeId,
        "latitude": position.latitude,
        "longitude": position.longitude,
        "socket_id": socketId,
        "role": "Driver",
        "heading": position.heading,
        "status": "stopped",
        "timestamp": DateTime.now().millisecondsSinceEpoch,
      });

      await Future.delayed(const Duration(milliseconds: 500));
    }
  } catch (e) {
    _updateNotification(
      title: "Location Error",
      content: "Failed to get final location: ${e.toString()}",
    );
  }
}

void _updateNotification({required String title, required String content}) {
  try {
    flutterLocalNotificationsPlugin.show(
      888,
      title,
      content,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          notificationChannelId,
          'VJ Bus Driver Service',
          importance: Importance.low,
          playSound: false,
          enableVibration: false,
          icon: '@mipmap/ic_launcher',
          ongoing: true,
          autoCancel: false,
          showWhen: false,
        ),
      ),
    );
  } catch (_) {}
}

IO.Socket _connectSocket(String? routeId, String role) {
  return IO.io(
    websocketUrl,
    IO.OptionBuilder()
        .setTransports(['websocket'])
        .setQuery({'role': role, 'route_id': routeId ?? 'Unknown'})
        .disableAutoConnect()
        .setReconnectionAttempts(5)
        .setReconnectionDelay(2000)
        .setTimeout(10000)
        .build(),
  )..connect();
}
